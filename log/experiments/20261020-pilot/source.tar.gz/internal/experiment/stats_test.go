package experiment

import "testing"

func TestPairedEffectResamplesPairs(t *testing.T) {
	got := pairedEffect([]float64{-4, -2, 2, 4})
	if got.MedianPercent != 0 || got.Pairs != 4 || got.BootstrapLowerPercent < -4 || got.BootstrapUpperPercent > 4 {
		t.Fatalf("effect: %+v", got)
	}
	if again := pairedEffect([]float64{-4, -2, 2, 4}); got != again {
		t.Fatal("bootstrap is not reproducible")
	}
}
